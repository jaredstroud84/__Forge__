// /api/claude.js
// This runs on the server, not in the browser — the API key never reaches the customer.
// Deploy this file inside an "api" folder at the root of your project on Vercel.
// Vercel auto-detects anything in /api as a serverless backend function.

export default async function handler(req, res) {
  // Only allow POST requests
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // Basic request size guard — keeps someone from sending a huge payload to run up costs
  const { prompt, system } = req.body || {};
  if (!prompt || typeof prompt !== "string" || prompt.length > 6000) {
    return res.status(400).json({ error: "Invalid request" });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY, // set in Vercel dashboard, never in code
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 2000,
        system: system || undefined,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Anthropic API error:", errText);
      return res.status(502).json({ error: "Upstream API error" });
    }

    const data = await response.json();
    const text = (data.content || []).map((b) => b.text || "").join("\n");
    return res.status(200).json({ text });
  } catch (err) {
    console.error("Server error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}
